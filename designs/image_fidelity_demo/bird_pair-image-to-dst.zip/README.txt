original/ is the uploaded file, unmodified (SHA-256 in SOURCE.json). Everything in derived/ was generated from it and is not a replacement for it.
